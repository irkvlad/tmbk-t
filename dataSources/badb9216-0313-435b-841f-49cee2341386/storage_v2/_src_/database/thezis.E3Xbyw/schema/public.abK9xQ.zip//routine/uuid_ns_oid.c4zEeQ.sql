create function uuid_ns_oid() returns uuid
  immutable
  strict
  parallel safe
  language c
as
$$
uuid_ns_oid
$$;

alter function uuid_ns_oid() owner to cuba;

