create function uuid_ns_x500() returns uuid
  immutable
  strict
  parallel safe
  language c
as
$$
uuid_ns_x500
$$;

alter function uuid_ns_x500() owner to cuba;

