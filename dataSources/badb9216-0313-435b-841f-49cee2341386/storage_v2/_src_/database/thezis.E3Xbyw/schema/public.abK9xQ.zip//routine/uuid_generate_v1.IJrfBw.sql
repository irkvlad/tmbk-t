create function uuid_generate_v1() returns uuid
  strict
  parallel safe
  language c
as
$$
uuid_generate_v1
$$;

alter function uuid_generate_v1() owner to cuba;

