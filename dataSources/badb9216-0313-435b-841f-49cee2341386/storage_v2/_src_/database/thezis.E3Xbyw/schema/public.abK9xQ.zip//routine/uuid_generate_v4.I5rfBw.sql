create function uuid_generate_v4() returns uuid
  strict
  parallel safe
  language c
as
$$
uuid_generate_v4
$$;

alter function uuid_generate_v4() owner to cuba;

