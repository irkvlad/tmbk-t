create view df_department_membership as
  WITH RECURSIVE hdep(correspondent_id, parent_department_id, level, top_level_id) AS (
    SELECT df_department.correspondent_id,
           df_department.parent_department_id,
           0 AS level,
           df_department.correspondent_id
    FROM df_department
    UNION ALL
    SELECT d1.correspondent_id,
           d1.parent_department_id,
           (d2.level + 1),
           d2.top_level_id
    FROM (df_department d1
           JOIN hdep d2 ON ((d1.parent_department_id = d2.correspondent_id)))
  )
  SELECT DISTINCT NULL::uuid         AS id,
                  e.user_id,
                  h.correspondent_id AS department_id
  FROM ((hdep h
    JOIN df_employee_department_pos edr ON (((edr.department_id = h.top_level_id) AND (edr.delete_ts IS NULL))))
         JOIN df_employee e ON (((e.correspondent_id = edr.employee_id) AND (e.user_id IS NOT NULL) AND
                                 ((h.top_level_id = h.correspondent_id) OR (EXISTS(SELECT r.id
                                                                                   FROM (sec_role r
                                                                                          JOIN sec_user_role ur ON ((
                                                                                       (r.id = ur.role_id) AND
                                                                                       (ur.user_id = e.user_id) AND
                                                                                       (ur.delete_ts IS NULL) AND
                                                                                       ((r.name)::text = 'DepartmentChief'::text))))))))));

alter table df_department_membership
  owner to root;

