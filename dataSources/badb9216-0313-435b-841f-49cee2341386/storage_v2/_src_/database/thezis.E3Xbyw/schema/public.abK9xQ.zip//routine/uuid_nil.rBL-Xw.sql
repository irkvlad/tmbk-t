create function uuid_nil() returns uuid
  immutable
  strict
  parallel safe
  language c
as
$$
uuid_nil
$$;

alter function uuid_nil() owner to cuba;

