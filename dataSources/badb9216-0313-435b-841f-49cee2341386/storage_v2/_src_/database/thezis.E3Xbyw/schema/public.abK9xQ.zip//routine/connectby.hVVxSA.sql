create function connectby(text, text, text, text, integer) returns SETOF record
  stable
  strict
  language c
as
$$
connectby_text
$$;

alter function connectby(text, text, text, text, int4) owner to root;

