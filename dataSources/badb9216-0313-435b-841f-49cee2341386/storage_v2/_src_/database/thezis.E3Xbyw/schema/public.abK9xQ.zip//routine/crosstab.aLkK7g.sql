create function crosstab(text) returns SETOF record
  stable
  strict
  language c
as
$$
crosstab
$$;

alter function crosstab(text, int4) owner to root;

