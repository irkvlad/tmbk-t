create function uuid_ns_dns() returns uuid
  immutable
  strict
  parallel safe
  language c
as
$$
uuid_ns_dns
$$;

alter function uuid_ns_dns() owner to cuba;

