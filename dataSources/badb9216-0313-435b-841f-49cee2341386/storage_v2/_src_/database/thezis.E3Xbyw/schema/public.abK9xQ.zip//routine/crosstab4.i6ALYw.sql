create function crosstab4(text) returns SETOF tablefunc_crosstab_4
  stable
  strict
  language c
as
$$
crosstab
$$;

alter function crosstab4(text) owner to root;

