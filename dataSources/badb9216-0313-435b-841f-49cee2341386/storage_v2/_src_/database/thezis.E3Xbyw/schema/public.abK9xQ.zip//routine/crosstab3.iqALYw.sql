create function crosstab3(text) returns SETOF tablefunc_crosstab_3
  stable
  strict
  language c
as
$$
crosstab
$$;

alter function crosstab3(text) owner to root;

