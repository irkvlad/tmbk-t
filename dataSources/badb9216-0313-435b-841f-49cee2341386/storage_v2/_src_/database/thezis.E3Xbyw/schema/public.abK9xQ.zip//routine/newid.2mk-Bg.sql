create function newid() returns uuid
  language sql
as
$$
select uuid_generate_v1();
$$;

alter function newid() owner to root;

