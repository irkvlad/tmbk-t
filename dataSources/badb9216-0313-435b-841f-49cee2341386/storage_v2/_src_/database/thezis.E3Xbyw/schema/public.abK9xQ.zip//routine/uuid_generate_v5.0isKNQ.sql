create function uuid_generate_v5(namespace uuid, name text) returns uuid
  immutable
  strict
  parallel safe
  language c
as
$$
uuid_generate_v5
$$;

alter function uuid_generate_v5(uuid, text) owner to cuba;

