create function crosstab2(text) returns SETOF tablefunc_crosstab_2
  stable
  strict
  language c
as
$$
crosstab
$$;

alter function crosstab2(text) owner to root;

