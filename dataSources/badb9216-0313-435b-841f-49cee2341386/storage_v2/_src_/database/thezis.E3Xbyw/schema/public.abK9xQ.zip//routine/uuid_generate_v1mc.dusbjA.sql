create function uuid_generate_v1mc() returns uuid
  strict
  parallel safe
  language c
as
$$
uuid_generate_v1mc
$$;

alter function uuid_generate_v1mc() owner to cuba;

