create function normal_rand(integer, double precision, double precision) returns SETOF double precision
  strict
  language c
as
$$
normal_rand
$$;

alter function normal_rand(int4, float8, float8) owner to root;

